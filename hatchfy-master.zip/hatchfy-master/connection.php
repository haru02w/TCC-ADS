<?php 
    $conn = mysqli_connect('millane.duckdns.org','users','t*D-MQ@!g78fd]K','BD_HATCHFY');
?>